package day05;

public class Movie {
	String title,director;
	
	public Movie() {
		
	}
	public Movie(String title, String director) {
		this.title=title;
		this.director = director;
		
	}

}

