package day05;
import java.util.*;
public class DiceGame {

	public static void main(String[] args) {
	int count = 0;
	
	Random rand = new Random();
	Dice dice1,dice2;
	while(true) {				
     dice1 = new Dice();
	 dice2 = new Dice(rand);
	count++;
	int num1 = dice1.i;
	int num2 = dice2.i;
	if(num1 + num2 ==2) {
		
		
		break;
	}
	
	System.out.println("주사위1:"+ dice1.i+"주사위2:"+dice2.i);
	
	}
	System.out.println("주사위1:"+ dice1.i+"주사위2:"+ dice2.i);
	System.out.println("(1,1)이 나온 횟수"+ count);
	}
}
