package day05;
import java.util.*;
public class MovieTest2 {

	public static void main(String[] args) {
		
		
		Scanner scan  = new Scanner(System.in);
		ArrayList<Movie> alist =new ArrayList<Movie>();
			   		
		    System.out.println("영화제목:");											
		    String title = scan.nextLine();
		    System.out.println("영화감독:");		
            String direc = scan.next();                   
		
		alist.add(new Movie(title,direc));
		
		for(Movie m1: alist) {
			System.out.print("{"+m1.title +","+ m1.director+"}");											
			
		}
 	}

}
