package day05;

class Student{
	private String name;
	private String rollno;
	private int age;
	static int count=0;
	
	public Student() {
		count++;
	}
	public Student(String name,String rollno, int age) {
		this.name = name;
		this.rollno = rollno;
		this.age = age;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setRollno(String name) {
		this.rollno = rollno;
	}
	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public String getRollno() {
		return rollno;
	}

	public int getAge() {
		return age;
	}
	

	public class StudentTest {
		public static void main(String[] args) {
			
			
		
		
		Student kim = new Student("kim","20180001",20);
		Student lee = new Student();
		
		
		Student sarray[] = new Student[3];
		sarray[0] = kim;
		sarray[1] = lee;
		sarray[2] = new Student("park","20190001",19);
		
		
		for(Student s: sarray) { 
			System.out.println(s.getName());
			System.out.println(s.getRollno());
			System.out.println(s.getAge());
			
		}
		System.out.println("학생의 이름:"+kim.getName());
		System.out.println("학생의 이름:"+kim.getRollno());
		System.out.println("학생의 이름:"+kim.getAge());
		
		lee.setName("lee");
		lee.setRollno("20170001");
		lee.setAge(25);
		System.out.println("학생의 이름: "+lee.getName());
		

		}
}
}
