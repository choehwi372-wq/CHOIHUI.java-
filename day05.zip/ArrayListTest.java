package day05;
import java.util.ArrayList;
import java.util.Random;
public class ArrayListTest {

	public static void main(String[] args) {
		
		ArrayList<String>alist = new ArrayList<String>();
		alist.add("홍콩");		
		alist.add("싱가포르");
		alist.add("괌");
		alist.add("사이판");
		alist.add("하와이");
		
		Random rand = new Random();				
	    System.out.println("여행지추천시스템입니다.");
	    int index = rand.nextInt(4);
	    System.out.println("추천여행지는"+alist.get(index));
		
		
		}
 	}


