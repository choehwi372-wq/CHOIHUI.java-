package day11;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ServerEx {
	ServerSocket ser;
	Socket sock;
	BufferedWriter pw;
	BufferedReader br;

	public ServerEx() {
		try {

			ser = new ServerSocket(9999);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("대기중 ");
		try {
			sock = ser.accept();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("클라이언트와 연결 성공");
		Scanner scanner = new Scanner(System.in);

		try {
			br = new BufferedReader(new InputStreamReader(sock.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			pw = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		while (true) {

			String inputMessage = "";
			try {
				inputMessage = br.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // 클라이언트로부터 한 행 읽기

			if (inputMessage.equalsIgnoreCase("bye")) {

				System.out.println("클라이언트에서 bye로 연결을 종료하였음");

				break; // "bye"를 받으면 연결 종료

			}

			System.out.println("클라이언트: " + inputMessage);

			System.out.print("보내기>>"); // 프롬프트

			String outputMessage = scanner.nextLine(); // 키보드에서 한 행 읽기

			try {
				pw.write(outputMessage + "\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // 키보드에서 읽은 문자열 전송

			try {
				pw.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // out의 스트림 버퍼에 있는 모든 문자열 전송

		}

	}

	public static void main(String[] args) {
		new ServerEx();

	}

}
