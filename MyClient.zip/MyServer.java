package day11;

import java.io.*;
import java.net.*;
import java.util.*;


public class MyServer {
	ServerSocket ser;
	Socket sock;
	BufferedWriter pw;
		
	public MyServer() {
		try {					
		ser = new ServerSocket(9999);
		System.out.println("대기중 "); 
		
		sock = ser.accept();
		System.out.println("클라이언트와 연결 성공");
		pw = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
		pw.write("서버로부터 >>>> 반갑습니다.");
		pw.flush();
		ser.close();
		sock.close();
		pw.close();
		
	}catch (IOException e) {
		e.printStackTrace();
	}
	}
		public static void main(String[] args) {
		new MyServer();
	}
		// TODO Auto-generated method stub

	}


