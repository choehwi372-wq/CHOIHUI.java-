package day11;
import java.io.*;
public class CopyFile3 {

	public static void main(String[] args) {
		try {
		FileInputStream fis = new FileInputStream("a.png");
		FileOutputStream fos = new FileOutputStream("b.a.png");
		int c;
		while((c = fis.read())!= -1) {
			fos.write(c);
		}
				
		fis.close();
		fos.close();

	}catch(Exception e) {
		e.printStackTrace();
	}

  }
}