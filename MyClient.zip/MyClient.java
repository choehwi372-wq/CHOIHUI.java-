package day11;
import java.io.*;
import java.net.*;


public class MyClient {

	Socket sock;
	BufferedReader br;
	
	
	
	public MyClient() {
		try {
			sock = new Socket("localhost",9999);
			System.out.println("서버연결 성공");
			br = new BufferedReader(new InputStreamReader(sock.getInputStream()));	
			String data="";
			while((data = br.readLine())!=null) {
				System.out.println("서버로 부터 >>" + data);
			}
			//sock.close();
			//br.close();
			
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	

	public static void main(String[] args) {
		new MyClient();
		// TODO Auto-generated method stub

	}

}
