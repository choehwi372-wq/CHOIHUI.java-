package day06;

public class CarTest {

	public static void main(String[] args) {
		
		SportsCar scar = new SportsCar();
		scar.speed = 100;
		scar.turn();
		
		
		// TODO Auto-generated method stub

	}

}
