package day06;

public class SportsCar extends Car {
	
	boolean turbo;
	
	public void setTurvo(boolean flag) {
		turbo = flag;
	}

}
