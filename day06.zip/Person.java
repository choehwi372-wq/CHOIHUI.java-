package day06;

public class Person {

// 추상화

String name, addr;

int age;


// 기본 생성자

public Person() {


}


// 인자 생성자

public Person(String name, String addr, int age) {

this.name = name;

this.addr = addr;

this.age = age;

}


// 사람의 모든 정보를 출력하는 메소드

public void showInfo() {

System.out.println("-----Person Info-----");

System.out.println(" 이름 : " + name);

System.out.println(" 주소 : " + addr);

System.out.println(" 나이 : " + age);

}


// 이름 정보를 반환하는 getName() 메소드

public String getName() {

return name;

}


}