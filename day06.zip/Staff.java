package day06;

public class Staff extends Person {

}
