package day06;

public class Teacher extends Person {
	
	String sfid;
	public Teacher() {
		super();
	}
	
	public void showInfo() {
		super.showInfo();
		System.out.println("사번: +sfid ");
		
	}
	
	
	//메소드 오버라이딩
	

}
