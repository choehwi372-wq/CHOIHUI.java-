package day10.my;

public interface MouseEventListener {

}
