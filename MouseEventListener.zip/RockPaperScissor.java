package day10.my;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.*;
public class RockPaperScissor extends JFrame implements ActionListener {
	
	 final int Rock = 0;
	 final int Paper = 1;
	 final int Scissor = 2;
	 
	 
	 private JPanel panel;
	 private Label output, information;
	 private JButton rock, paper, scissor;
	 
	 
	 public RockPaperScissor() {
		 setTitle("가위, 바위, 보");
		  setSize(400, 150);
		  panel = new JPanel();
		  panel.setLayout(new GridLayout(0, 3));   
		  information = new Label("아래의버튼중에서하나를클릭하시오!");
		  output = new Label("Good Luck!");
		  rock = new JButton("0: 바위");
		  paper = new JButton("1: 보");
		  scissor = new JButton("2: 가위");
		  //이벤트 처리 객체 등록하기
		  rock.addActionListener(this); 
		  paper.addActionListener(this); 
		  scissor.addActionListener(this);  
		  
		  panel.add(rock);
		  panel.add(paper);
		  panel.add(scissor);
		  
		  add(information, BorderLayout.NORTH);
		  add(panel, BorderLayout.CENTER);
		  add(output, BorderLayout.SOUTH);
		  setVisible(true);
		  
		  
		  
		  
		  setDefaultCloseOperation(EXIT_ON_CLOSE);
		  setVisible(true);
	 }
	
	
	

	public static void main(String[] args) {
		new RockPaperScissor();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
				
		
		JButton obj = (JButton)e.getSource();
		
		int user = Integer.parseInt(""+obj.getText().charAt(0)); 
		Random random = new Random();
	    int computer = random.nextInt(3); 
		if( user == computer)
		     output.setText("인간과컴퓨터가비겼음");
		else if( user == (computer+1)%3) 
		     output.setText("인간: "+user+" 컴퓨터: "+computer+" 인간승리");
		else
		     output.setText("인간: "+user+" 컴퓨터: "+computer+"컴퓨터승리");
	
		
	}

}
