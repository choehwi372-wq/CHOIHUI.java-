package day10.my;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

class MyFrame extends JFrame{
	Label label;
	JButton jbtn1;
	public MyFrame() {
		setSize(600,150);
		setTitle("피자 주문 창");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		JPanel jp1= new JPanel();
		JPanel jp2= new JPanel();
		JPanel jp3= new JPanel();
		label =new Label("자바 피자에 오신 것을 환영합니다. 피자의 종류를 선택하시오.");
		
		jp2.add (label);
		
		
		jbtn1 = new  JButton("불고기피자");		
		
		jbtn1.addActionListener(new MyListener());
		jp3.add(jbtn1);
		jp3.add(new JButton("치즈 피자"));
		jp3.add(new JButton("콤비네이션 피자"));
		
		jp2.add(new Label("개수"));
		jp3.add(new JTextField(10));
		
		jp1.add(jp2);
		jp1.add(jp3);		
		this.add(jp1);
		setVisible(true);
	}
		
	
		
	class MyListener implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent e) {
			label.setText((jbtn1.getText()));
			
			
			
       }
		
	}
	
}
public class MyFrameTest {

	public static void main(String[] args) {
		 new MyFrame2();
		
		// TODO Auto-generated method stub

	}

}
