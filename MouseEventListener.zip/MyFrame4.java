package day10.my;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MyFrame4 extends JFrame {
	int x, y;

	class MyPanel extends JPanel {
		public MyPanel() {
			this.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					x = e.getX();
					y = e.getY();
					repaint();

				}
			});

		}

		protected void paintComponent(Graphics g) { // (1)
			super.paintComponent(g);

			g.setColor(Color.BLUE);
			g.fillRect(x, y, 100, 100);
		}
	}

	public MyFrame4() {
		setTitle("Basic Painting");
		setSize(600, 200);
		add(new MyPanel());
		setVisible(true);
	}

	public static void main(String[] args) {
		MyFrame4 f = new MyFrame4();
	}
}
