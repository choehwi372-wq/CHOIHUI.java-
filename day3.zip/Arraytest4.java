package day03;

import java.util.ArrayList;

public class Arraytest4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	ArrayList<String> list = new ArrayList<>();
	list.add("철수");
	list.add("영희");
	list.add("최휘"); 
	
	String name = list.get(0);
	list.remove(1);
	for (String k: list);
	System.out.println(k);
	}
	
		

	


}