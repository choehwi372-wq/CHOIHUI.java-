package day03;

public class Arraytest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1차원 배열 선언
		String[] toppings = {"peperoni","Mushroom","Onions","sausage","bacon"};
			for(String i : toppings) {
				System.out.println(i);				
		
	}
	
	int list[] = {100,200,300,400,500};
	int total = 0;
	for(int i : list) {
		total = total + i;
		
	}
	System.out.println(total);
		
		
		
	
		

	}

}
