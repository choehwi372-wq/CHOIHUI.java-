package day03;

public class Arraytest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//2차원 배열 선언
		int[][] list2 = {
		                 {10,20,30},
		                 {40,50,60},
		                 {70,80,90}};
			
        for(int j=0; j<list2.length; j++) {
        	for(int i =0; i<list2[j].length; i++) {
        	System.out.println("list2[" + j +"]["+i+"]="+list2[j][i]);
        }
	
		

	}

}
}