package day03;
import java.util.Scanner;
public class GuGuDan {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in); 
	
		System.out.println("구구단 중에서 출력하고 싶은 단을 입력하시오" );
		int 단 = 2;
			int i = 1;
			while (단 <=9) {
				System.out.println(단);
				단 = scan.nextInt();
			while(i<=9) {
				System.out.println(단+"*"+i+ "="+ 단 * i + (단*i));
				
				i++;
		}
	
	
		}
	    i=1;
		단++;
		
		

	}

}
