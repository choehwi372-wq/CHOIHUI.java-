package day03;
import java.util.Scanner;
public class ForTest {
        //for(초기식;조건식;증강식){ }
	    //
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i, j;
		for(i =2;i<=9;i++) {
			for(j =1; j<=9; j++) {
				System.out.println( i+"*" + j + "="+ (i*j));
			}
			
		}

	}

}
