package day03;

public class Test {

	public static void main(String[] args) {
		
		int i = 1;
		int sum = 0;
		while(i<=100) {
		sum = sum+i;
	
		i++;
		}
		System.out.println("합계"+ sum);
		// TODO Auto-generated method stub

	}

}
