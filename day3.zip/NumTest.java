package day03;
import java.util.*;
public class NumTest {

	public static void main(String[] args) {
		int com, user, count = 0 ;	
		Random rand = new Random();
		com = rand.nextInt(99)+2;
		do {		
		System.out.println(com);
		System.out.print("정답을 추측하여 보시오:");
		Scanner scan = new Scanner(System.in);
		
		
		user = scan.nextInt();
		if(com>user) {
			System.out.println("high");
			count++;
		}
		else if(com < user) {
			System.out.println("Low");
			count++;
		}
		else if(com == user) {
			System.out.println("정답!");
		}
			
			
			
		}
		while(com != user);
		System.out.println("게임횟수:"+ count);
		}
}

		// TODO Auto-generated method stub
		//컴퓨터가 1부터 100사이의 임의 수 생성하기
		// user 입력

	
	


